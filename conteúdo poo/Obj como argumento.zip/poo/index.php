<?php 

// Incluindo os arquivos
include("Racao.php");
include("AnimalInterface.php");
include("Animal.php");
include("Cachorro.php");
include("Gato.php");

// Tenta executar o código
try {

    // Instanciando a classe Racao
    $racaoCao = new Racao(
        "Ração para Cachorro",
        "Pedigree",
        20.00
    );

    // Instanciando a classe Racao
    $racaoGato = new Racao(
        "Ração para Gato",
        "Whiskas",
        15.00
    );

    // Instanciando a classe Cachorro
    $cao = new Cachorro(
        "Totó",
        "Vira-lata",
        5,
        "Caramelo"
    );
    
    // Instanciando a classe Gato
    $gato = new Gato(
        "Mingau",
        "Vira-lata",
        3,
        "Branco"
    );

    // Setando a ração do cachorro
    $cao->setRacao($racaoCao);

    $cao->falar(); // O animal fala
    $cao->andar();
    $cao->comer();

    // Exibe o nome da ração do cachorro
    echo "A ração do cachorro é: " . $cao->getRacao()->getNome() . "<br>";


    $gato->falar(); // O animal fala
    $gato->andar();

    // Exibe o nome da ração do gato
    echo "O doguinho chama: " . $cao->getNome() . "<br>";
} catch (Exception $e) {
    // Exibe a mensagem de erro
    echo "Erro: " . $e->getMessage();
}
