<?php 

class Racao {
    private $nome;
    private $marca;
    private $preco;

    public function __construct($nome, $marca, $preco) {
        $this->nome = $nome;
        $this->marca = $marca;
        $this->preco = $preco;
    }

    public function getNome() {
        return $this->nome;
    }

    public function getMarca() {
        return $this->marca;
    }

    public function getPreco() {
        return $this->preco;
    }
}