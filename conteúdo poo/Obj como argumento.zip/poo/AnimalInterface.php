<?php 

interface AnimalInterface {
    public function falar();

    public function andar();

    public function comer();
}