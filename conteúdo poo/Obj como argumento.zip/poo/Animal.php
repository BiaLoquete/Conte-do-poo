<?php 

class Animal {
    private $nome;
    private $raca;
    private $idade;
    private $cor;

    public function __construct($nome, $raca, $idade, $cor) {
        $this->nome = $nome;
        $this->raca = $raca;
        $this->cor = $cor;

        // Verificar se idade não é numero 
        if (!is_numeric($idade)) {
            throw new Exception("Idade deve ser um número");
        }

        $this->idade = $idade;
    }

    public function getNome() {
        return $this->nome;
    }

    public function getRaca() {
        return $this->raca;
    }

    public function getIdade() {
        return $this->idade;
    }

    public function getCor() {
        return $this->cor;
    }

    public function falar() {
        echo "O animal fala";
    }
}