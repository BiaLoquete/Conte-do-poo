<?php 

class Cachorro extends Animal implements AnimalInterface {

    private $racao;

    public function __construct($nome, $raca, $idade, $cor) {
        parent::__construct($nome, $raca, $idade, $cor);
    }

    public function setRacao(Racao $racao) {
        $this->racao = $racao;
    }

    public function getRacao() {
        return $this->racao;
    }

    public function falar() {
        echo "O cachorro fala: Au Au Au <br>";
    }

    public function andar() {
        echo "O cachorro anda: 4 patas <br>";
    }

    public function comer() {
        echo "O cachorro come: Ração <br>";
    }
}
